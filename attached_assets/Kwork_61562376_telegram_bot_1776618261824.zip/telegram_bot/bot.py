#!/usr/bin/env python3
"""
Telegram-бот раздачи файла по секретному слову.
Автор: Andres_tech (Kwork заказ #61562376)

Настройка:
  1. Получите BOT_TOKEN у @BotFather
  2. Укажите CHANNEL_ID вашего канала (например @dnorca или числовой ID)
  3. Задайте SECRET_WORD — кодовое слово
  4. Укажите DISK_LINK — ссылку на Яндекс.Диск с файлом
"""

import logging
import os
from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    filters, ContextTypes
)

# ─── Конфигурация ────────────────────────────────────────────────────────────
# Можно задать через переменные окружения или прямо здесь:
BOT_TOKEN   = os.getenv("BOT_TOKEN",   "YOUR_BOT_TOKEN_HERE")
CHANNEL_ID  = os.getenv("CHANNEL_ID",  "@dnorca")
SECRET_WORD = os.getenv("SECRET_WORD", "хочу")
DISK_LINK   = os.getenv("DISK_LINK",   "https://disk.yandex.ru/d/c6M_CbirwiK2vQ")
# ─────────────────────────────────────────────────────────────────────────────

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Приветственное сообщение."""
    await update.message.reply_text(
        "👋 Привет! Напишите кодовое слово, чтобы получить ссылку на файл."
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатываем входящее сообщение."""
    if update.message is None:
        return

    text = (update.message.text or "").strip().lower()
    keyword = SECRET_WORD.strip().lower()

    if keyword in text:
        logger.info(f"Secret word matched from user {update.effective_user.id}")
        await update.message.reply_text(
            f"✅ Правильно! Вот ваша ссылка:\n{DISK_LINK}",
            disable_web_page_preview=False,
        )
    else:
        await update.message.reply_text(
            "❓ Не понял. Введите правильное кодовое слово."
        )


def main() -> None:
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ Ошибка: задайте BOT_TOKEN в config.env или прямо в bot.py")
        return

    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info(f"Бот запущен. Секретное слово: «{SECRET_WORD}»")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
